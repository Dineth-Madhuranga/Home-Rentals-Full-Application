import React from 'react'
import "../styles/Slide.scss"

const Slide = () => {
    return (
        <div className='slide'>
            <h1>
                Welcome to CodeCrew Home Rentals!
            </h1>
        </div>
    )
}

export default Slide